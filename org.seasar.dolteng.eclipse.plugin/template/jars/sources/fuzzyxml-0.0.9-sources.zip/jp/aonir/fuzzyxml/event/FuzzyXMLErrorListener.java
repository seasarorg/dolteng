package jp.aonir.fuzzyxml.event;

public interface FuzzyXMLErrorListener {
	public void error(FuzzyXMLErrorEvent event);
}
