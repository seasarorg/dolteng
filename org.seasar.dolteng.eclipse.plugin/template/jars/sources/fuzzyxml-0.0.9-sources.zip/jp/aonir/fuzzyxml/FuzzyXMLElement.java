package jp.aonir.fuzzyxml;

public interface FuzzyXMLElement extends FuzzyXMLNode {
	
	public String getName();
	
	
	public FuzzyXMLNode[] getChildren();
	
	public boolean hasChildren();
	
	public void appendChild(FuzzyXMLNode node);
	
//	public void appendChildrenFromText(String text);
	
	public void insertBefore(FuzzyXMLNode newChild,FuzzyXMLNode refChild);
	
	public void replaceChild(FuzzyXMLNode newChild,FuzzyXMLNode refChild);
	
	public void removeChild(FuzzyXMLNode oldChild);
	
	
	public FuzzyXMLAttribute[] getAttributes();
	
	public void setAttribute(FuzzyXMLAttribute attr);
	
	public boolean hasAttribute(String name);
	
	public FuzzyXMLAttribute getAttributeNode(String name);
	
	public void removeAttributeNode(FuzzyXMLAttribute attr);
	
	public String getValue();
	
	public void removeAllChildren();
	
}
