package jp.aonir.fuzzyxml;

public interface FuzzyXMLProcessingInstruction extends FuzzyXMLNode {
	public String getData();
	public String getName();
	public void setData(String data);
}
