package jp.aonir.fuzzyxml;

public interface FuzzyXMLCDATA extends FuzzyXMLNode {
    public String getValue();
}
